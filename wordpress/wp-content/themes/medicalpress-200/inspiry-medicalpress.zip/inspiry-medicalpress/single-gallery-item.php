<?php
/*
 *  Single Gallery
 */

get_template_part( INSPIRY_PARTIALS . '/gallery/single/single-gallery' );