<?php
/**
 * The template for displaying all pages
 */

get_template_part( INSPIRY_PARTIALS . '/page/page' );