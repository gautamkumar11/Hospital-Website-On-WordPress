<?php
/*
 *  Taxonomy Department
 */

get_template_part( INSPIRY_PARTIALS . '/gallery/taxonomy-gallery-item-type' );