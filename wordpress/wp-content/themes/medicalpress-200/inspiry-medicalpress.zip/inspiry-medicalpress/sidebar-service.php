<aside class="sidebar clearfix">
    <?php dynamic_sidebar('service-detail-page'); ?>
</aside>