<?php if ( inspiry_is_reCAPTCHA_configured() ) : ?>
    <div class="inspiry-recaptcha-wrapper clearfix">
        <div class="inspiry-google-recaptcha"></div>
    </div>
    <input type="hidden" name="inspiry_is_reCAPTCHA_configured" value="1"/>
<?php endif; ?>