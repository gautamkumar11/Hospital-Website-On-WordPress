<aside class="sidebar clearfix">
    <?php dynamic_sidebar('default'); ?>
</aside>