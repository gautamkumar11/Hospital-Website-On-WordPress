<?php
/**
 *  Archive
 */

get_template_part( INSPIRY_PARTIALS . '/page/archive' );