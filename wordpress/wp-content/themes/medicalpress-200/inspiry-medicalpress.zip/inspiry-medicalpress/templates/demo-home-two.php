<?php
/*
 *  Template Name: Demo - Home Variation Two
 */
get_header();

get_template_part( INSPIRY_PARTIALS . '/page/demo-home-two' );

get_footer();