<?php
/*
 *  Template Name: FAQs Full Width Template
 */

get_template_part( INSPIRY_PARTIALS . '/page/page-faq-fullwidth' );