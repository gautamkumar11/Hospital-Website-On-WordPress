<?php
/*
 *  Template Name: Demo - Home Revolution Slider
 */
get_header();

get_template_part( INSPIRY_PARTIALS . '/page/demo-home-five' );

get_footer();