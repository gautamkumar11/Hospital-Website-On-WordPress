<?php
/**
 *  Search
 */

get_template_part( INSPIRY_PARTIALS . '/page/search' );