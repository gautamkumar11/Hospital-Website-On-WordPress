<?php
/*
 *  Taxonomy Department
 */

get_template_part( INSPIRY_PARTIALS . '/doctor/taxonomy-department' );