<?php
/* Standard post format for grid layout */
inspiry_standard_thumbnail('blog-post-thumb');
?>