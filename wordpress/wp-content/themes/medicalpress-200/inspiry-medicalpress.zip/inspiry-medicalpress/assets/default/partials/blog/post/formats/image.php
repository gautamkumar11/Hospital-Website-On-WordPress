<?php
/* For image post format - there is no difference between standard and image post. */
inspiry_standard_thumbnail();

