<div class="gallery gallery-slider clearfix loading">
    <?php
    /* Gallery post format for grid layout */
    inspiry_list_gallery_images('blog-post-thumb')
    ?>
</div>