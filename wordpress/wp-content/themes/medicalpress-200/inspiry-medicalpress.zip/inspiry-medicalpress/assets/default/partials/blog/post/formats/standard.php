<?php
/* For standard post format */
inspiry_standard_thumbnail();