<?php
/*
 * Call to Action
 */
get_template_part( INSPIRY_PARTIALS . '/footer/footer-call-to-action' ); ?>

<footer id="site-footer" class="site-footer">
	<?php get_template_part( INSPIRY_PARTIALS . '/footer/footer-top' ); ?>
    <?php get_template_part( INSPIRY_PARTIALS . '/footer/footer-bottom' ); ?>
</footer><!-- .site-footer -->