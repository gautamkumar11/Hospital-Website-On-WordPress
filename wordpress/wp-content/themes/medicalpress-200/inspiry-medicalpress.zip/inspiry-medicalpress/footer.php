
    <?php get_template_part( INSPIRY_ASSETS . '/partials/footer/footer' ); ?>

</div><!-- #page -->
<a id="scroll-top" class="scroll-top" href="#top"><i class="fa fa-chevron-up"></i></a>
<?php wp_footer(); ?>
</body>
</html>